{
    "name": "Quiz Bulk Import",
    "version": "1.0",
    "category": "eLearning",
    "depends": ["website_slides"],
    "data": [
        "views/quiz_import_views.xml"
    ],
    "installable": True,
    "application": False
}
