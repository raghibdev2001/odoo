import base64
import csv
from odoo import models, fields, api
from odoo.exceptions import UserError


class CoursePublishImportWizard(models.TransientModel):
    _name = 'course.publish.import.wizard'
    _description = 'Import Publish Status for Courses'

    file = fields.Binary(string="CSV File", required=True)
    filename = fields.Char(string="Filename")

    def action_import(self):
        if not self.file:
            raise UserError("Please upload a CSV file.")

        data = base64.b64decode(self.file)
        lines = data.decode('utf-8').splitlines()
        reader = csv.DictReader(lines)

        for row in reader:
            course_name = row.get('course name', '').strip()
            content_name = row.get('course content', '').strip()
            publish_status = row.get('publish status', '').strip().lower() == 'true'

            if not course_name:
                continue

            course = self.env['slide.channel'].search([('name', '=', course_name)], limit=1)
            if not course:
                continue

            if content_name == 'all':
                for content in course.slide_ids:
                    content.website_published = publish_status
                course.website_published = publish_status
            else:
                content = self.env['slide.slide'].search([
                    ('name', '=', content_name),
                    ('channel_id', '=', course.id)
                ], limit=1)
                if content:
                    content.website_published = publish_status

        return {"type": "ir.actions.act_window_close"}
