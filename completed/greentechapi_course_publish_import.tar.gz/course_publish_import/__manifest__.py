{
    "name": "Course Publish Import",
    "version": "1.0",
    "author":   "Raghib Khesal",
    "category": "Tools",
    "depends": ["website_slides"],
    "summary": "Import publish/unpublish status for courses and contents",
    "data": [
        "views/import_publish_wizard_view.xml",
    ],
    "installable": True,
    "application": False,
}
